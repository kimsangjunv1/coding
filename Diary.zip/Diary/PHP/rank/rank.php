<?php 
    include "../../connect/connect.php";
    include "../../connect/session.php";
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>랭크</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/board.css">
    <link rel="stylesheet" href="../../assets/css/rank.css">

</head>
<body>
    <div class="wrap">
        <div class="site">
            <?php include "../include/header.php" ?>

            <div class="board">
                <div class="board_info">
                    <img src="../../assets/img/site_main_rank.png" class="header_icon_main" alt="">
                    <img src="../../assets/img/site_main_rank_heart.png" class="header_icon_01" alt="">
                    <img src="../../assets/img/site_main_rank_heart.png" class="header_icon_02" alt="">
                    <img src="../../assets/img/site_main_rank_heart.png" class="header_icon_03" alt="">
                    <img src="../../assets/img/site_main_rank_heart.png" class="header_icon_04" alt="">
                    <img src="../../assets/img/site_main_rank_heart.png" class="header_icon_05" alt="">
                    
                    <h2>RANKING</h2>
                    <p>오늘의 인기 게시물 순위!!!</p>
                    <img src="../../assets/img/site_board_notice_cross.png" alt="">
                </div>
                <div class="board__rank__view">
                    <div class="board__rank__inner">
                        <div class="rank_header">
                            <div class="rank_header_left">
                                <h2>이달의 랭크</h2>
                                <p>Month</p>
                            </div>
                            <div class="rank_header_right">
                                <div>사용빈도 1위</div>
                                <div>?</div>
                            </div>
                        </div>
                        <div class="rank_cont">
                            <div class="rank_cont_big3">
                                <div class="rank_sum rank_two">
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="2등"></a>
                                    <span class="num1 two">2</span>
                                    <span class="name1 two_name">팬더 스티커</span>
                                </div>
                                <div class="rank_sum rank_first">
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="1등"></a>
                                    <span class="num1 one">1</span>
                                    <span class="name2 one_name">다이어리</span>
                                </div>
                                <div class="rank_sum rank_three">
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="3등"></a>
                                    <span class="num1 three">3</span>
                                    <span class="name3 three_name">포켓몬 스티커</span>
                                </div>
                            </div>
                            <div class="rank_cont_small">
                                <div class="rank_sum2">
                                    <div class="num2">4</div>
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="4등"></a>
                                    <div class="name4">동물 스티커</div>
                                </div>
                                <div class="rank_sum2">
                                    <div class="num2">5</div>
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="5등"></a>
                                    <div class="name4">식물 스티커</div>
                                </div>
                                <div class="rank_sum2">
                                    <div class="num2">6</div>
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="6등"></a>
                                    <div class="name4">인간 스티커</div>
                                </div>
                                <div class="rank_sum2">
                                    <div class="num2">7</div>
                                    <a href="#"><img src="../../assets/img/function_edit_sticker_01.png" alt="7등"></a>
                                    <div class="name4">옷 스티커</div>
                                </div>
                            </div>
                        </div>
                    </div>    
                </div>
            </div>
        </div>
        <?php include "../include/footer.php" ?>
    </div>
</body>
<script>document.querySelector(".header_inner a:nth-child(5)").classList.add("actived")</script>
</html>